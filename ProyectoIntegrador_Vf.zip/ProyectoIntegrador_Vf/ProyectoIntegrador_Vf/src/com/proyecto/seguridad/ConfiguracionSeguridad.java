package com.proyecto.seguridad;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.Properties;

/**
 * Configuración de seguridad de la transmisión (objetivo específico 1).
 *
 * Se leen dos cosas de un archivo "seguridad.properties":
 *   - el TOKEN compartido entre el servidor y los agentes (autenticación), y
 *   - el almacén de certificados TLS (cifrado del canal):
 *        SERVIDOR -> keystore   (certificado + clave privada)
 *        AGENTE   -> truststore (solo el certificado público del servidor)
 *
 * El archivo y los certificados los crea {@link GeneradorCredenciales}, y se
 * buscan en la carpeta  seguridad/servidor  o  seguridad/agente  (relativa a
 * la carpeta desde donde se ejecuta el programa). Esa carpeta se puede cambiar con
 *     -Dproyecto.seguridad=RUTA        o la variable de entorno PROYECTO_SEGURIDAD
 *
 * Las rutas escritas dentro del .properties son relativas a la carpeta del
 * propio archivo, así que basta con copiar la carpeta completa a otro equipo.
 */
public final class ConfiguracionSeguridad {

    /** Quién usa la configuración: define qué claves se exigen. */
    public enum Rol { SERVIDOR, AGENTE }

    /** Error de configuración con un mensaje listo para mostrarle al usuario. */
    public static class ErrorConfiguracion extends Exception {
        private static final long serialVersionUID = 1L;

        public ErrorConfiguracion(String mensaje) {
            super(mensaje);
        }
    }

    public static final String PROPIEDAD_CARPETA = "proyecto.seguridad";
    public static final String VARIABLE_CARPETA = "PROYECTO_SEGURIDAD";
    public static final String NOMBRE_ARCHIVO = "seguridad.properties";

    private static final int LONGITUD_MINIMA_TOKEN = 16;

    private final String token;
    private final byte[] huellaToken;
    private final Path rutaAlmacen;
    private final char[] claveAlmacen;

    private ConfiguracionSeguridad(String token, Path rutaAlmacen, char[] claveAlmacen) {
        this.token = token;
        this.huellaToken = sha256(token);
        this.rutaAlmacen = rutaAlmacen;
        this.claveAlmacen = claveAlmacen;
    }

    // ------------------------------------------------------------------
    // Carga
    // ------------------------------------------------------------------

    public static ConfiguracionSeguridad cargar(Rol rol) throws ErrorConfiguracion {
        Path carpeta = carpetaDe(rol);
        Path archivo = carpeta.resolve(NOMBRE_ARCHIVO);

        if (!Files.isRegularFile(archivo)) {
            throw new ErrorConfiguracion(
                    "No se encontró la configuración de seguridad:\n  " + archivo
                    + "\n\nGenérela una sola vez ejecutando la clase\n"
                    + "  com.proyecto.seguridad.GeneradorCredenciales\n"
                    + "en el equipo del servidor y copie la carpeta seguridad/agente "
                    + "a cada equipo cliente.\n"
                    + "(Otra carpeta se indica con -D" + PROPIEDAD_CARPETA + "=RUTA)");
        }

        Properties p = new Properties();
        try (Reader lector = Files.newBufferedReader(archivo, StandardCharsets.UTF_8)) {
            p.load(lector);
        } catch (IOException e) {
            throw new ErrorConfiguracion("No se pudo leer " + archivo + ": " + e.getMessage());
        }

        String token = exigir(p, "token", archivo);
        if (token.length() < LONGITUD_MINIMA_TOKEN) {
            throw new ErrorConfiguracion("El token de " + archivo + " es demasiado corto (mínimo "
                    + LONGITUD_MINIMA_TOKEN + " caracteres). Vuelva a generar las credenciales.");
        }

        String claveArchivo = rol == Rol.SERVIDOR ? "keystore" : "truststore";
        String nombreAlmacen = exigir(p, claveArchivo, archivo);
        String clave = exigir(p, claveArchivo + ".password", archivo);

        Path almacen = carpeta.resolve(nombreAlmacen).normalize();
        if (!Files.isRegularFile(almacen)) {
            throw new ErrorConfiguracion("No existe el archivo de certificados indicado en "
                    + archivo + ":\n  " + almacen);
        }

        return new ConfiguracionSeguridad(token, almacen, clave.toCharArray());
    }

    private static Path carpetaDe(Rol rol) {
        String indicada = System.getProperty(PROPIEDAD_CARPETA);
        if (indicada == null || indicada.isBlank()) {
            indicada = System.getenv(VARIABLE_CARPETA);
        }
        if (indicada != null && !indicada.isBlank()) {
            return Paths.get(indicada.trim()).toAbsolutePath().normalize();
        }
        String subcarpeta = rol == Rol.SERVIDOR ? "servidor" : "agente";
        return Paths.get("seguridad", subcarpeta).toAbsolutePath().normalize();
    }

    private static String exigir(Properties p, String clave, Path archivo) throws ErrorConfiguracion {
        String valor = p.getProperty(clave);
        if (valor == null || valor.isBlank()) {
            throw new ErrorConfiguracion("Falta la propiedad '" + clave + "' en " + archivo);
        }
        return valor.trim();
    }

    // ------------------------------------------------------------------
    // Uso
    // ------------------------------------------------------------------

    /** Token que el agente envía al servidor. */
    public String getToken() {
        return token;
    }

    /**
     * Compara el token recibido con el esperado en tiempo constante: se comparan
     * los hashes SHA-256, y MessageDigest.isEqual no se detiene en el primer byte
     * distinto, así que el tiempo de respuesta no filtra cuántos caracteres acertó
     * quien intenta adivinarlo.
     */
    public boolean tokenCoincide(String recibido) {
        if (recibido == null) {
            return false;
        }
        return MessageDigest.isEqual(huellaToken, sha256(recibido));
    }

    public Path getRutaAlmacen() {
        return rutaAlmacen;
    }

    public char[] getClaveAlmacen() {
        return claveAlmacen.clone();
    }

    private static byte[] sha256(String texto) {
        try {
            return MessageDigest.getInstance("SHA-256").digest(texto.getBytes(StandardCharsets.UTF_8));
        } catch (java.security.NoSuchAlgorithmException e) {
            // SHA-256 está garantizado en toda JVM.
            throw new IllegalStateException(e);
        }
    }
}

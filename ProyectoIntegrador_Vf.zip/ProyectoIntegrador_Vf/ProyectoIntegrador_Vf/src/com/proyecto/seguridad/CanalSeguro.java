package com.proyecto.seguridad;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.TrustManagerFactory;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.file.Files;
import java.security.GeneralSecurityException;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Crea los sockets cifrados con TLS que usan el servidor y los agentes.
 *
 * Qué garantiza el canal:
 *   - CONFIDENCIALIDAD / INTEGRIDAD: todo lo que viaja (comandos, respuestas,
 *     métricas) va cifrado; quien capture el tráfico en la red no ve nada legible.
 *   - AUTENTICIDAD DEL SERVIDOR: el agente solo confía en el certificado exacto que
 *     tiene en su truststore, así que no puede ser engañado por un servidor falso.
 *     (Por eso no hace falta verificar el nombre/IP del host: la identidad se
 *     comprueba por el certificado fijado, y el servidor puede cambiar de IP.)
 *   - AUTENTICIDAD DEL AGENTE: la hace el token que se envía dentro del canal ya
 *     cifrado (ver ManejadorCliente / AgenteCliente).
 */
public final class CanalSeguro {

    /** Respuesta del servidor cuando el token es correcto. */
    public static final String ACCESO_OK = "@@OK";

    /** Respuesta del servidor cuando el token es incorrecto. */
    public static final String ACCESO_DENEGADO = "@@DENEGADO";

    /**
     * Tiempo máximo para completar el saludo (TLS + token). Evita que una conexión
     * que no dice nada mantenga un hilo del servidor ocupado.
     */
    public static final int TIMEOUT_SALUDO_MS = 5000;

    private static final String TIPO_ALMACEN = "PKCS12";
    private static final List<String> PROTOCOLOS_PERMITIDOS = Arrays.asList("TLSv1.3", "TLSv1.2");

    private CanalSeguro() {
    }

    /**
     * Abre el puerto de escucha del servidor con TLS. Falla de inmediato (y con un
     * mensaje claro) si el keystore no existe, está dañado o la clave es incorrecta.
     */
    public static ServerSocket crearServidor(int puerto, ConfiguracionSeguridad config)
            throws IOException, GeneralSecurityException {

        KeyStore almacen = cargarAlmacen(config);

        KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
        char[] clave = config.getClaveAlmacen();
        try {
            kmf.init(almacen, clave);
        } finally {
            java.util.Arrays.fill(clave, '\0');
        }

        SSLContext contexto = SSLContext.getInstance("TLS");
        contexto.init(kmf.getKeyManagers(), null, null);

        SSLServerSocket socket = (SSLServerSocket) contexto.getServerSocketFactory().createServerSocket(puerto);
        socket.setEnabledProtocols(protocolosSoportados(socket.getSupportedProtocols()));
        return socket;
    }

    /**
     * Conecta un agente con el servidor y completa el saludo TLS. Al volver, el
     * canal ya está cifrado y el servidor ya demostró ser quien dice ser.
     *
     * Lanza SSLException (subclase de IOException) si el certificado del servidor
     * no es el que el agente tiene fijado en su truststore.
     */
    public static Socket conectar(String ip, int puerto, int timeoutMs, ConfiguracionSeguridad config)
            throws IOException, GeneralSecurityException {

        KeyStore almacen = cargarAlmacen(config);

        TrustManagerFactory tmf = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
        tmf.init(almacen);

        SSLContext contexto = SSLContext.getInstance("TLS");
        contexto.init(null, tmf.getTrustManagers(), null);

        SSLSocket socket = (SSLSocket) contexto.getSocketFactory().createSocket();
        try {
            socket.setEnabledProtocols(protocolosSoportados(socket.getSupportedProtocols()));
            socket.connect(new InetSocketAddress(ip, puerto), timeoutMs);
            socket.setSoTimeout(timeoutMs);
            socket.startHandshake();
            return socket;
        } catch (IOException | RuntimeException e) {
            try {
                socket.close();
            } catch (IOException ignorada) {
                // Ya se va a informar el error original.
            }
            throw e;
        }
    }

    private static KeyStore cargarAlmacen(ConfiguracionSeguridad config)
            throws IOException, GeneralSecurityException {

        KeyStore almacen = KeyStore.getInstance(TIPO_ALMACEN);
        char[] clave = config.getClaveAlmacen();
        try (InputStream entrada = Files.newInputStream(config.getRutaAlmacen())) {
            almacen.load(entrada, clave);
        } finally {
            java.util.Arrays.fill(clave, '\0');
        }
        return almacen;
    }

    /** Se queda solo con TLS 1.3 / 1.2 (nunca SSL ni TLS 1.0/1.1). */
    private static String[] protocolosSoportados(String[] soportados) {
        List<String> disponibles = Arrays.asList(soportados);
        List<String> elegidos = new ArrayList<>();
        for (String protocolo : PROTOCOLOS_PERMITIDOS) {
            if (disponibles.contains(protocolo)) {
                elegidos.add(protocolo);
            }
        }
        if (elegidos.isEmpty()) {
            throw new IllegalStateException("Esta versión de Java no soporta TLS 1.2 ni 1.3.");
        }
        return elegidos.toArray(new String[0]);
    }
}

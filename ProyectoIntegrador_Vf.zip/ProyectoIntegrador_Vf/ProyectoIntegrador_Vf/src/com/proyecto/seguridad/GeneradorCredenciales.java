package com.proyecto.seguridad;

import java.io.File;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.PosixFilePermissions;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;

/**
 * Herramienta de una sola ejecución que prepara la seguridad del proyecto.
 *
 * Crea, dentro de la carpeta  seguridad/  (en la carpeta desde donde se ejecuta):
 *
 *   seguridad/servidor/   -> para el equipo del Servidor Central
 *       servidor.p12            certificado + clave privada (SECRETO)
 *       seguridad.properties    token + clave del keystore (SECRETO)
 *
 *   seguridad/agente/     -> para copiar a CADA equipo cliente
 *       agente-truststore.p12   solo el certificado público del servidor
 *       seguridad.properties    token + clave del truststore
 *
 * Uso:
 *   java -cp out com.proyecto.seguridad.GeneradorCredenciales            (crea todo)
 *   java -cp out com.proyecto.seguridad.GeneradorCredenciales --forzar   (regenera)
 *
 * Si se regenera, hay que volver a copiar seguridad/agente a todos los clientes.
 * La carpeta seguridad/ NO debe subirse a Git.
 */
public final class GeneradorCredenciales {

    private static final String ALIAS = "servidor";
    private static final int DIAS_VALIDEZ = 730;
    private static final String VAR_CLAVE_KEYSTORE = "PROYECTO_CLAVE_KEYSTORE";
    private static final String VAR_CLAVE_TRUSTSTORE = "PROYECTO_CLAVE_TRUSTSTORE";

    private GeneradorCredenciales() {
    }

    public static void main(String[] args) {
        boolean forzar = Arrays.asList(args).contains("--forzar");

        Path base = Paths.get("seguridad").toAbsolutePath().normalize();
        Path carpetaServidor = base.resolve("servidor");
        Path carpetaAgente = base.resolve("agente");

        try {
            if (Files.exists(carpetaServidor.resolve(ConfiguracionSeguridad.NOMBRE_ARCHIVO)) && !forzar) {
                System.err.println("Ya existen credenciales en " + base);
                System.err.println("Si las regenera, deberá volver a copiar seguridad/agente a todos los clientes.");
                System.err.println("Para regenerarlas ejecute de nuevo con el argumento --forzar");
                System.exit(1);
            }

            Files.createDirectories(carpetaServidor);
            Files.createDirectories(carpetaAgente);

            Path keystore = carpetaServidor.resolve("servidor.p12");
            Path truststore = carpetaAgente.resolve("agente-truststore.p12");
            Path certificado = carpetaServidor.resolve("servidor.crt");

            // Con --forzar se parte de cero: keytool no sobrescribe alias existentes.
            Files.deleteIfExists(keystore);
            Files.deleteIfExists(truststore);
            Files.deleteIfExists(certificado);

            String token = aleatorio(32);
            String claveKeystore = aleatorio(24);
            String claveTruststore = aleatorio(24);

            // 1) Par de claves RSA + certificado autofirmado del servidor.
            keytool(VAR_CLAVE_KEYSTORE, claveKeystore,
                    "-genkeypair",
                    "-alias", ALIAS,
                    "-keyalg", "RSA", "-keysize", "3072", "-sigalg", "SHA256withRSA",
                    "-validity", String.valueOf(DIAS_VALIDEZ),
                    "-dname", "CN=ServidorCentral, O=ProyectoIntegrador",
                    "-storetype", "PKCS12",
                    "-keystore", keystore.toString(),
                    "-storepass:env", VAR_CLAVE_KEYSTORE);

            // 2) Se exporta SOLO el certificado público...
            keytool(VAR_CLAVE_KEYSTORE, claveKeystore,
                    "-exportcert",
                    "-alias", ALIAS,
                    "-keystore", keystore.toString(),
                    "-storepass:env", VAR_CLAVE_KEYSTORE,
                    "-rfc",
                    "-file", certificado.toString());

            // 3) ...y se mete en el truststore que recibirán los agentes.
            keytool(VAR_CLAVE_TRUSTSTORE, claveTruststore,
                    "-importcert",
                    "-alias", ALIAS,
                    "-file", certificado.toString(),
                    "-storetype", "PKCS12",
                    "-keystore", truststore.toString(),
                    "-storepass:env", VAR_CLAVE_TRUSTSTORE,
                    "-noprompt");

            Files.deleteIfExists(certificado);

            escribirPropiedades(carpetaServidor.resolve(ConfiguracionSeguridad.NOMBRE_ARCHIVO),
                    "Configuración de seguridad del SERVIDOR CENTRAL. SECRETO: no subir a Git ni compartir.",
                    "token=" + token,
                    "keystore=servidor.p12",
                    "keystore.password=" + claveKeystore);

            escribirPropiedades(carpetaAgente.resolve(ConfiguracionSeguridad.NOMBRE_ARCHIVO),
                    "Configuración de seguridad del AGENTE. Copiar esta carpeta a cada equipo cliente.",
                    "token=" + token,
                    "truststore=agente-truststore.p12",
                    "truststore.password=" + claveTruststore);

            soloPropietario(keystore);
            soloPropietario(carpetaServidor.resolve(ConfiguracionSeguridad.NOMBRE_ARCHIVO));

            System.out.println("Credenciales creadas en: " + base);
            System.out.println();
            System.out.println("  Servidor : " + carpetaServidor + "  (se queda en este equipo)");
            System.out.println("  Agentes  : " + carpetaAgente + "  (copiar a cada cliente)");
            System.out.println();
            System.out.println("En cada cliente, la carpeta 'agente' debe quedar en  seguridad/agente");
            System.out.println("dentro de la carpeta desde la que se ejecuta el agente.");
            System.out.println("El certificado es válido " + DIAS_VALIDEZ + " días.");

        } catch (IOException | InterruptedException | RuntimeException e) {
            System.err.println("No se pudieron generar las credenciales: " + e.getMessage());
            System.exit(1);
        }
    }

    /** Ejecuta keytool del mismo JDK con que se está corriendo este programa. */
    private static void keytool(String variableClave, String clave, String... argumentos)
            throws IOException, InterruptedException {

        List<String> comando = new ArrayList<>();
        comando.add(rutaKeytool());
        comando.addAll(Arrays.asList(argumentos));

        ProcessBuilder pb = new ProcessBuilder(comando);
        pb.redirectErrorStream(true);
        // La clave viaja por variable de entorno para que no aparezca en la lista de procesos.
        pb.environment().put(variableClave, clave);

        Process proceso;
        try {
            proceso = pb.start();
        } catch (IOException e) {
            throw new IOException("No se pudo ejecutar keytool (" + comando.get(0) + "). "
                    + "Ejecute este programa con un JDK completo.", e);
        }

        String salida = new String(proceso.getInputStream().readAllBytes(), StandardCharsets.UTF_8);
        if (proceso.waitFor() != 0) {
            throw new IOException("keytool falló:\n" + salida.trim());
        }
    }

    private static String rutaKeytool() {
        boolean windows = System.getProperty("os.name", "").toLowerCase().contains("win");
        File local = new File(System.getProperty("java.home"), "bin" + File.separator
                + (windows ? "keytool.exe" : "keytool"));
        return local.isFile() ? local.getAbsolutePath() : "keytool";
    }

    /** Texto aleatorio criptográficamente seguro (Base64 URL, sin caracteres problemáticos). */
    private static String aleatorio(int bytes) {
        byte[] datos = new byte[bytes];
        new SecureRandom().nextBytes(datos);
        return Base64.getUrlEncoder().withoutPadding().encodeToString(datos);
    }

    private static void escribirPropiedades(Path archivo, String comentario, String... lineas)
            throws IOException {
        StringBuilder sb = new StringBuilder("# ").append(comentario).append(System.lineSeparator());
        for (String linea : lineas) {
            sb.append(linea).append(System.lineSeparator());
        }
        Files.write(archivo, sb.toString().getBytes(StandardCharsets.UTF_8));
    }

    /** En Linux/macOS deja el archivo legible solo por el dueño; en Windows no aplica. */
    private static void soloPropietario(Path archivo) {
        try {
            Files.setPosixFilePermissions(archivo, PosixFilePermissions.fromString("rw-------"));
        } catch (UnsupportedOperationException | IOException ignorada) {
            // Sistema de archivos sin permisos POSIX (Windows): se ignora.
        }
    }
}
